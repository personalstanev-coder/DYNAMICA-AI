import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timezone

st.set_page_config(page_title="DYNAMICA AI | XAUUSD", page_icon="📈", layout="wide")

st.markdown("""
<style>
.block-container {padding-top: 1.2rem; padding-bottom: 2rem; max-width: 1200px;}
[data-testid="stMetric"] {background: rgba(120,120,120,.08); padding: 12px; border-radius: 10px;}
.small-note {font-size: .88rem; opacity: .8;}
</style>
""", unsafe_allow_html=True)

st.title("📈 DYNAMICA AI")
st.caption("XAUUSD · H1 · Intraday · Прототип за анализ, не система за изпълнение на сделки")
st.info("Този прототип анализира само подадените от теб CSV данни. Не получава автоматично котировки или новини и не изпраща поръчки към брокер.")

REQUIRED = ["timestamp", "open", "high", "low", "close", "volume"]

def rsi(series, period=14):
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1/period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1/period, min_periods=period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    out = 100 - (100 / (1 + rs))
    out = out.mask((avg_loss == 0) & (avg_gain > 0), 100)
    out = out.mask((avg_gain == 0) & (avg_loss > 0), 0)
    return out

def add_indicators(df):
    d = df.copy()
    for n in (20, 50, 200):
        d[f"EMA{n}"] = d["close"].ewm(span=n, adjust=False, min_periods=n).mean()
    d["RSI14"] = rsi(d["close"], 14)
    fast = d["close"].ewm(span=12, adjust=False).mean()
    slow = d["close"].ewm(span=26, adjust=False).mean()
    d["MACD"] = fast - slow
    d["MACD_signal"] = d["MACD"].ewm(span=9, adjust=False).mean()
    d["MACD_hist"] = d["MACD"] - d["MACD_signal"]
    prev_close = d["close"].shift(1)
    tr = pd.concat([
        d["high"] - d["low"],
        (d["high"] - prev_close).abs(),
        (d["low"] - prev_close).abs()
    ], axis=1).max(axis=1)
    d["ATR14"] = tr.ewm(alpha=1/14, min_periods=14, adjust=False).mean()
    return d

def validate_csv(raw):
    errors, warnings = [], []
    missing_cols = [c for c in REQUIRED if c not in raw.columns]
    if missing_cols:
        errors.append("Липсващи колони: " + ", ".join(missing_cols))
        return None, errors, warnings
    d = raw[REQUIRED].copy()
    d["timestamp"] = pd.to_datetime(d["timestamp"], errors="coerce", utc=True)
    for c in REQUIRED[1:]:
        d[c] = pd.to_numeric(d[c], errors="coerce")
    bad_time = int(d["timestamp"].isna().sum())
    if bad_time:
        errors.append(f"{bad_time} реда имат невалиден timestamp.")
    numeric_bad = int(d[REQUIRED[1:]].isna().any(axis=1).sum())
    if numeric_bad:
        errors.append(f"{numeric_bad} реда имат липсващи или нечислови OHLCV стойности.")
    d = d.dropna(subset=REQUIRED).copy()
    if d.empty:
        errors.append("Няма валидни редове за анализ.")
        return None, errors, warnings
    if (d[["open", "high", "low", "close"]] <= 0).any().any():
        errors.append("OHLC цените трябва да са положителни.")
    invalid_ohlc = (d["high"] < d[["open", "low", "close"]].max(axis=1)) | (d["low"] > d[["open", "high", "close"]].min(axis=1))
    if invalid_ohlc.any():
        errors.append(f"{int(invalid_ohlc.sum())} реда имат несъответстващи High/Low стойности.")
    if (d["volume"] < 0).any():
        errors.append("Volume не може да е отрицателен.")
    d = d.sort_values("timestamp").drop_duplicates("timestamp", keep="last").reset_index(drop=True)
    if len(d) < 30:
        warnings.append("Има под 30 валидни свещи. Част от индикаторите няма да са налични.")
    if len(d) > 1:
        gaps = d["timestamp"].diff().dropna()
        unusual = int((gaps > pd.Timedelta(hours=2)).sum())
        if unusual:
            warnings.append(f"Открити са {unusual} времеви празнини над 2 часа. Провери дали данните са пълни.")
    return d, errors, warnings

def freshness_label(last_timestamp):
    # Сравняваме само с реалното UTC време; това е възраст на последния запис, не гаранция за live feed.
    age = pd.Timestamp.now(tz="UTC") - last_timestamp
    if age < pd.Timedelta(hours=2):
        return "FRESH", "Последният запис е от последните 2 часа. Това не доказва, че източникът е live."
    return "STALE", f"Последният запис е на {age.total_seconds()/3600:.1f} часа. Данните се маркират като остарели."

def strategy_check(d, data_status):
    required_cols = ["EMA20", "EMA50", "EMA200", "RSI14", "MACD", "MACD_signal", "ATR14"]
    if data_status != "FRESH":
        return "WAIT", [], [], ["Данните са STALE или липсват; не се допуска BUY/SELL сигнал."]
    if len(d) < 201 or d[required_cols].iloc[-2].isna().any():
        return "WAIT", [], [], ["Недостатъчна история за пълния набор индикатори на последната затворена свещ."]
    # -2: последната свещ се приема за потенциално незатворена и не се използва за потвърждение.
    c = d.iloc[-2]
    checks = [
        ("Затворена H1 цена над EMA20", c["close"] > c["EMA20"]),
        ("EMA20 над EMA50", c["EMA20"] > c["EMA50"]),
        ("EMA50 над EMA200", c["EMA50"] > c["EMA200"]),
        ("RSI в положителна, но не екстремна зона (50–70)", 50 <= c["RSI14"] <= 70),
        ("MACD над сигналната линия", c["MACD"] > c["MACD_signal"]),
    ]
    passed = [name for name, ok in checks if ok]
    failed = [name for name, ok in checks if not ok]
    unknown = []
    if len(passed) == len(checks):
        return "BUY", passed, failed, unknown
    # Симетрична базова проверка за SELL
    sell_checks = [
        ("Затворена H1 цена под EMA20", c["close"] < c["EMA20"]),
        ("EMA20 под EMA50", c["EMA20"] < c["EMA50"]),
        ("EMA50 под EMA200", c["EMA50"] < c["EMA200"]),
        ("RSI в отрицателна, но не екстремна зона (30–50)", 30 <= c["RSI14"] <= 50),
        ("MACD под сигналната линия", c["MACD"] < c["MACD_signal"]),
    ]
    sell_pass = [name for name, ok in sell_checks if ok]
    sell_fail = [name for name, ok in sell_checks if not ok]
    if len(sell_pass) == len(sell_checks):
        return "SELL", sell_pass, sell_fail, unknown
    return "WAIT", passed, failed, ["Няма пълно съвпадение на всички BUY или SELL условия."]

uploaded = st.file_uploader("Качи CSV файл с H1 OHLCV данни", type=["csv"])
with st.expander("Формат на CSV файла и пример"):
    st.code("timestamp,open,high,low,close,volume\n2026-11-10T09:00:00Z,4100.0,4105.0,4098.0,4103.0,1200", language="csv")
    st.caption("Очаквани колони: timestamp, open, high, low, close, volume. Времето се интерпретира като UTC, ако няма часова зона.")

if uploaded is None:
    st.warning("Качи CSV файл, за да започне анализът. Не са добавени измислени пазарни котировки.")
    st.stop()

try:
    raw = pd.read_csv(uploaded)
except Exception as exc:
    st.error(f"Файлът не може да бъде прочетен: {exc}")
    st.stop()

df, errors, warnings = validate_csv(raw)
for msg in warnings:
    st.warning(msg)
if errors:
    for msg in errors:
        st.error(msg)
    st.stop()

df = add_indicators(df)
freshness, freshness_text = freshness_label(df["timestamp"].iloc[-1])
if freshness == "FRESH":
    st.success(f"Статус на данните: {freshness}")
else:
    st.warning(f"Статус на данните: {freshness}")
st.caption(freshness_text)
st.caption(f"Последна времева отметка: {df['timestamp'].iloc[-1].strftime('%Y-%m-%d %H:%M UTC')} · Валидни свещи: {len(df)}")

last = df.iloc[-1]
c1, c2, c3, c4 = st.columns(4)
c1.metric("Последно Close", f"{last['close']:,.2f}")
c2.metric("EMA 20", "—" if pd.isna(last["EMA20"]) else f"{last['EMA20']:,.2f}")
c3.metric("RSI 14", "—" if pd.isna(last["RSI14"]) else f"{last['RSI14']:.1f}")
c4.metric("ATR 14", "—" if pd.isna(last["ATR14"]) else f"{last['ATR14']:.2f}")

fig = make_subplots(rows=3, cols=1, shared_xaxes=True, vertical_spacing=0.06,
                    row_heights=[0.58, 0.2, 0.22],
                    subplot_titles=("XAUUSD · H1 Price & EMA", "RSI 14", "MACD"))
fig.add_trace(go.Candlestick(x=df["timestamp"], open=df["open"], high=df["high"], low=df["low"], close=df["close"], name="H1"), row=1, col=1)
for col in ("EMA20", "EMA50", "EMA200"):
    fig.add_trace(go.Scatter(x=df["timestamp"], y=df[col], mode="lines", name=col), row=1, col=1)
fig.add_trace(go.Scatter(x=df["timestamp"], y=df["RSI14"], mode="lines", name="RSI14"), row=2, col=1)
fig.add_hline(y=70, line_dash="dot", row=2, col=1)
fig.add_hline(y=30, line_dash="dot", row=2, col=1)
fig.add_trace(go.Bar(x=df["timestamp"], y=df["MACD_hist"], name="MACD histogram"), row=3, col=1)
fig.add_trace(go.Scatter(x=df["timestamp"], y=df["MACD"], name="MACD"), row=3, col=1)
fig.add_trace(go.Scatter(x=df["timestamp"], y=df["MACD_signal"], name="Signal"), row=3, col=1)
fig.update_layout(height=850, xaxis_rangeslider_visible=False, legend_orientation="h", margin=dict(l=10,r=10,t=50,b=10))
st.plotly_chart(fig, use_container_width=True)

st.subheader("Начална оценка на условията")
signal, passed, failed, unknown = strategy_check(df, freshness)
if signal == "BUY":
    st.success("BUY · Всички базови BUY условия са изпълнени на последната затворена свещ.")
elif signal == "SELL":
    st.error("SELL · Всички базови SELL условия са изпълнени на последната затворена свещ.")
else:
    st.warning("WAIT · Няма достатъчно потвърждение за BUY или SELL.")

left, middle, right = st.columns(3)
with left:
    st.markdown("**Изпълнени условия**")
    if passed:
        for item in passed: st.write("✅ " + item)
    else: st.write("— Няма")
with middle:
    st.markdown("**Неизпълнени условия**")
    if failed:
        for item in failed: st.write("❌ " + item)
    else: st.write("— Няма")
with right:
    st.markdown("**Неизвестни / липсващи**")
    if unknown:
        for item in unknown: st.write("❔ " + item)
    else: st.write("— Няма")

st.caption("Важно: BUY/SELL/WAIT е демонстрационна логика, а не инвестиционна препоръка. Няма стоп, тейк-профит, позиционен размер или backtest. Не използвай сигнала самостоятелно за реална сделка.")
with st.expander("Технически бележки"):
    st.write("- За потвърждение стратегията използва предпоследния ред (-2), за да не приема последната потенциално незатворена H1 свещ.")
    st.write("- Статусът FRESH означава само, че timestamp-ът е скорошен спрямо часовника на средата. Не удостоверява произход, непрекъснат поток или точност на котировките.")
    st.write("- CSV трябва да съдържа достатъчно история; EMA200 изисква поне 200 свещи.")
